$(document).ready(function(){
  
  /* 1. Visualizing things on Hover - See next part for action on click */
  $('#stars li').on('mouseover', function(){
    var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on
   
    // Now highlight all the stars that's not after the current hovered star
    $(this).parent().children('li.star').each(function(e){
      if (e < onStar) {
        $(this).addClass('hover');
      }
      else {
        $(this).removeClass('hover');
      }
    });
    
  }).on('mouseout', function(){
    $(this).parent().children('li.star').each(function(e){
      $(this).removeClass('hover');
    });
  });
  
  
  /* 2. Action to perform on click */
  $('#stars li').on('click', function(){
    var onStar = parseInt($(this).data('value'), 10); // The star currently selected
    var stars = $(this).parent().children('li.star');
    
    for (i = 0; i < stars.length; i++) {
      $(stars[i]).removeClass('selected');
    }
    
    for (i = 0; i < onStar; i++) {
      $(stars[i]).addClass('selected');
    }
    
    // JUST RESPONSE (Not needed)
	var section = document.getElementsByClassName("rating-stars text-center")[0].id;
    var rate = parseInt($('#stars li.selected').last().data('value'), 10); 
	 
	  
	$.ajax({ 
		
		
		
		url : "https://docs.google.com/forms/d/e/1FAIpQLSej6_U7-hilfCNmIc5G449SDc9jgA_9m6KFrNmbuAg07Ks5Cw/formResponse", //Get the key from the link ti the form
		data: { 
		  "entry.71209161": section, //Get the entry numbers by inspecting the entry field name in the form
		  "entry.1424796153": rate, 
		},



		type: "POST",
		dataType: "xml",
		statusCode: {
		  0: function () {
			alert('success');
		  },
		  200: function () {
			alert('fail');
		  }
		}
	})
	  
	
    var msg = "";
    if (rate > 3) {
        msg = "Thank you for your feedback.<br>You rated this section (" + section + ") " + rate + " stars.<br>We are glad you liked it!";
    }
    else {
        msg = "Thank you for your feedback.<br>You rated this section (" + section + ") " + rate + " stars.<br>We will work on improving it.";
    }
    responseMessage(msg);
    
  });
  
  
});


//function responseMessage(msg) {
//  $('.success-box').fadeIn(200);  
//  $('.success-box div.text-message').html("<span>" + msg + "</span>");
//}

