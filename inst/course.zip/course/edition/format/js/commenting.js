//selector from your HTML form
$('#comment-form').submit(function(e) {
  //prevent the form from submiting so we can post to the google form
  e.preventDefault();
  //AJAX request
	
	var section = document.getElementById("comment-form").name;; // The star currently selected
    var comment = document.getElementsByName("inputcomment")[0].value;
	
  $.ajax({
    
	  
	  
	url : "https://docs.google.com/forms/d/e/1FAIpQLSdoLwWSg8Wv5Gh_v-2kr6LqCPDhb3sArr1AF5wlLrnIalvzmA/formResponse", //Get the key from the link ti the form
	data: { 
	  "entry.343313760": section, //Get the entry numbers by inspecting the entry field name in the form
	  "entry.450938714": comment, 
	},
	  
	  
	  
	type: 'POST', //tells ajax to post the data to the url
    dataType: "xml", //the standard data type for most ajax requests
    
	statusCode: { //the status code from the POST request
      0: function(data) { //0 is when Google gives a CORS error, don't worry it went through
        //success
        $('#form-success').text('Thank you for your question, comment, or suggestion!');
      }, 
      200: function(data) {//200 is a success code. it went through!
        //success
        $('#form-success').text('Thank you for your question, comment, or suggestion!');
      },
      403: function(data) {//403 is when something went wrong and the submission didn't go through
        //error
        alert('Oh no! something went wrong. we should check our code to make sure everything matches with Google');
      }
    }  
  });
});

