if (base::file.exists("data/environment.RData"))
  base::load("data/environment.RData")