

```{r}
s1 <- "Part 1"
s2 <- "Part 2"
s3 <- "Part 3"
editR::add_slide(title = "Agenda")
editR::add_list(
  c(s1,s2,s3),
  numbered = FALSE,
  animation = "semi-fade-out"
)
```



```{r}
editR::add_slide(
  title = base::paste0("<chalk> ", s1, " </chalk>"),
  section = TRUE,
  color = "#000000",
  image_url = "https://e-catalyst.net/common/img/backgrounds/blackboard.jpg"
)
```



```{r}
editR::add_slide(
  title = base::paste0("<chalk> Thank you! Any question? </chalk>"),
  section = TRUE,
  color = "#000000",
  image_url = "https://e-catalyst.net/common/img/backgrounds/blackboard.jpg"
)
```



```{r}
editR::add_slide(title = "References")
```



Meta-information
================
exextra[title]:Title of the slide presentation.  
exextra[authors]:Nicolas Mangin  
exextra[type]:Slide  
exextra[document]:SXXXXXXXXX  

