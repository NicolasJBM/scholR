#' @name dbl
#' @title Format as numeric
#' @author Nicolas Mangin
#' @description Function formating as a number with the specified number of digits.
#' @param x Double or Integer. Number to be properly formatted.
#' @param digits Integer. Number of digits.
#' @return Character. Formatted number.
#' @export

dbl <- function(x = 1.234, digits = 2) {
  
  base::stopifnot(
    base::is.numeric(x),
    base::is.numeric(digits),
    digits >= 0
  )
  
  nbr <- base::length(x)
  z <- base::character(nbr)
  
  for (i in base::seq_len(nbr)){
    
    if (base::is.na(x[i])) {
      
      z[i] <- NA
      
    } else {
      
      z[i] <- base::format(
        x[i], big.mark = ",",
        decimal.mark = ".",
        scientific = F,
        digits = digits,
        nsmall = 2
      )
      
    }
  }
  
  return(z)
}
  
