#' @name pct
#' @title Format percentages
#' @author Nicolas Mangin
#' @description Function transforming numbers between 0 and 1 in percentages.
#' @param x Double or Integer. Number to be properly formatted.
#' @param digits Integer. Number of digits.
#' @return Character. Formated number.
#' @export

pct <- function(x = 0.12345, digits = 2) {
  
  stopifnot(
    is.numeric(x),
    is.numeric(digits),
    digits >= 0
  )
  
  nbr <- base::length(x)
  z <- base::character(nbr)
  
  for (i in base::seq_len(nbr)){
    if (base::is.na(x[i])) {
      z[i] <- NA
    } else {
      z[i] <- base::format(
        x[i] * 100,
        big.mark = ",",
        decimal.mark = ".",
        scientific = F,
        digits = digits,
        nsmall = 2
      )
    }
  }
  
  return(z)
} 
